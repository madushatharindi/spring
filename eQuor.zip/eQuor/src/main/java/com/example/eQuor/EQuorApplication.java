package com.example.eQuor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EQuorApplication {

	public static void main(String[] args) {
		SpringApplication.run(EQuorApplication.class, args);
	}

}
