package com.example.eQuor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EQuorApplicationTests {

	@Test
	void contextLoads() {
	}

}
